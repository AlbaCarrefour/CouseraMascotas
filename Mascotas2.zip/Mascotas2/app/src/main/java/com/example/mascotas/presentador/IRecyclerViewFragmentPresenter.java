package com.example.mascotas.presentador;

public interface IRecyclerViewFragmentPresenter {
    void obtenerMascotasBaseDatos();
    void obtenerTopCincoMascotasBaseDatos();
    void mostrarMascotasRV();
}
