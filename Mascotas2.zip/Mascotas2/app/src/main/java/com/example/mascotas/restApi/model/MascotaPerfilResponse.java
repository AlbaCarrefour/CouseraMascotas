package com.example.mascotas.restApi.model;

import com.example.mascotas.model.MascotaPerfil;

public class MascotaPerfilResponse {
    MascotaPerfil mascotaPerfil;

    public MascotaPerfil getMascotaPerfil() {
        return mascotaPerfil;
    }

    public void setMascotaPerfil(MascotaPerfil mascotaPerfil) {
        this.mascotaPerfil = mascotaPerfil;
    }
}
